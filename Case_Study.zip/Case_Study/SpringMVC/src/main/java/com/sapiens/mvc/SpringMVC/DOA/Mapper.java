package com.sapiens.mvc.SpringMVC.DOA;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sapiens.mvc.SpringMVC.model.Insurance;

public class Mapper implements RowMapper<Insurance>{
	 public Insurance mapRow(ResultSet rs, int rowNum) throws SQLException {
         // TODO Auto-generated method stub
         Insurance inform = new Insurance();
         inform.setInsurancePolicyNumber(rs.getInt("insurancePolicyNumber"));
         inform.setFirstName(rs.getString("firstName"));
         inform.setLastName(rs.getString("lastname"));
         inform.setDateOfBirth(rs.getString("dateOfBirth"));
         inform.setEmail(rs.getString("email"));
         inform.setContactNumber(rs.getString("contactNumber"));
         inform.setGender(rs.getString("gender"));
         inform.setTobacco(rs.getString("tobacco"));
         inform.setAnnualIncome(rs.getInt("AnnualIncome"));
         inform.setPolicyType(rs.getString("policyType"));
         inform.setPolicyStatus(rs.getString("PolicyStatus"));
         inform.setAgeOfInsurance(rs.getInt("ageOfInsurance"));
         return inform;
     }

}
