package com.sapiens.mvc.SpringMVC.DOA;
import java.util.List;

import com.sapiens.mvc.SpringMVC.model.Insurance;
public interface InsuranceDAO {
	
	List<Insurance> showAll();

    public void  saveOrUpdate(Insurance ins);

    public void  updateStatus(Insurance ins);
    public void  rejectStatus(Insurance ins);

	void delete(Insurance ins);

	//public void delete(Insurance ins);

	
}