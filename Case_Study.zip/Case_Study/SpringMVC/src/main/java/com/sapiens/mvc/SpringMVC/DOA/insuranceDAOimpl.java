package com.sapiens.mvc.SpringMVC.DOA;

import java.util.*;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.sapiens.mvc.SpringMVC.model.Insurance;

public class insuranceDAOimpl implements InsuranceDAO {
	 private JdbcTemplate jdbc;

     private final String SQL_GET_ALL = "SELECT * FROM insurance";
     private final String SQL_INSERT_ALL = "insert into insurance values (?,?,?,?,?,?,?,?,?,?,?,?)";
     private final String SQL_UPD = "update insurance set PolicyStatus = 'accepted' where insurancePolicyNumber=(?)";
     private final String SQL_RJTD = "update insurance set PolicyStatus = 'rejected' where insurancePolicyNumber=(?)";
     private final String SQL_DEL = "delete from insurance where insurancePolicyNumber=(?)";
     public insuranceDAOimpl(DataSource datasource) {
         jdbc = new JdbcTemplate(datasource);
     }


     public List<Insurance> showAll(){
          return jdbc.query(SQL_GET_ALL, new Mapper());
     }

     public void saveOrUpdate (Insurance ins) {
         jdbc.update(SQL_INSERT_ALL, ins.getInsurancePolicyNumber(),ins.getFirstName(), ins.getLastName(), ins.getDateOfBirth(), ins.getEmail(), ins.getContactNumber(), ins.getGender(), ins.getTobacco(), ins.getAnnualIncome(),ins.getPolicyType(), ins.getPolicyStatus(),ins.getAgeOfInsurance());
     }


	
	@Override
	public void updateStatus(Insurance ins) {
		// TODO Auto-generated method stub
		jdbc.update(SQL_UPD, ins.getInsurancePolicyNumber());
	}


	@Override
	public void rejectStatus(Insurance ins) {
		// TODO Auto-generated method stub
		jdbc.update(SQL_RJTD, ins.getInsurancePolicyNumber());
	}
	@Override
	public void delete(Insurance ins) {
		// TODO Auto-generated method stub
		jdbc.update(SQL_DEL, ins.getInsurancePolicyNumber());
	}

}
 

