package com.sapiens.mvc.SpringMVC.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.RequestBody;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sapiens.mvc.SpringMVC.DOA.InsuranceDAO;
import com.sapiens.mvc.SpringMVC.model.Insurance;

@Controller
public class HomeController {
	
       @Autowired
       private InsuranceDAO insurer;

	@RequestMapping(value="/",method=RequestMethod.GET)
    public ModelAndView login(ModelAndView model) {
        model.setViewName("Login");
        return model;
        }
 @RequestMapping(value="/home")
        public <Insurance> ModelAndView list(ModelAndView model)throws IOException{ 
        List<Insurance> list = (List<Insurance>) insurer.showAll();
        model.addObject("list", list);
        model.setViewName("home");
        return model;    
    }
  @RequestMapping(value = "/validate")
    public String validate(@RequestParam("username") String user,@RequestParam("password") String password) {

        if ( (user).equals("Bharat")&& (password).equals("1234")) {

            return ("redirect:/home");


        }else{

            return ("redirect:/aa");

    }
        
}
  @RequestMapping(value="/Cancel")
  public String cancel()
  {
	  return ("redirect:/");
  }
  @RequestMapping(value="/aa")
    public ModelAndView login1(ModelAndView model) {
        Insurance in= new Insurance();
        model.addObject("insurer", in);
        model.setViewName("ProposalForm");

        return model;
    }

  @RequestMapping(value = "/save", method = RequestMethod.POST)
    public ModelAndView saveContact(@ModelAttribute Insurance insurers) {
        insurers.setPolicyStatus("pending");
        insurer.saveOrUpdate(insurers);        
        return new ModelAndView("redirect:/home");
    }

  @RequestMapping("/accept")
  public ModelAndView data(@ModelAttribute Insurance ins, HttpServletRequest request) {
      int id=Integer.parseInt(request.getParameter("id"));
      ins.setInsurancePolicyNumber(id);
      insurer.updateStatus(ins);
      return new ModelAndView("redirect:/home");
  }

  @RequestMapping(value="/reject", method= RequestMethod.GET)
  public ModelAndView reject(@ModelAttribute Insurance ins,HttpServletRequest request) {
      int id=Integer.parseInt(request.getParameter("id"));
      ins.setInsurancePolicyNumber(id);
      insurer.rejectStatus(ins);
      return new ModelAndView("redirect:/home");
}
  @RequestMapping(value = "/delete", method = RequestMethod.GET)
  public ModelAndView delete(@ModelAttribute Insurance ins,HttpServletRequest request) {
      int id = Integer.parseInt(request.getParameter("id"));
      ins.setInsurancePolicyNumber(id);
      insurer.delete(ins);
      return new ModelAndView("redirect:/home");
  }

 
}